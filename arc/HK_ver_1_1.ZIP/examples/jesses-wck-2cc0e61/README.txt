Please see the WIKI for documentation:

http://wiki.github.com/jesses/wck/