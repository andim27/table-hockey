// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

function hideAjaxSpinner() { $('AjaxSpinner').hide(); }
function showAjaxSpinner() { $('AjaxSpinner').show(); }


// =======================================================================

String.prototype.normalize = function () {return this.replace(/^\s+/, '').replace(/\s+$/, '')}

var RollOverOnList = Class.create();

RollOverOnList.prototype = {
	initialize: function(elementName) {	
		this.list = $(elementName);
		this.listName = elementName;
		
   	this.options = Object.extend({
      tag: 'li',
			hoverClassName: 'hover',
			except: 'active',			
			alternateClasses: null,
			show: null,
			disableFor: null
    }, arguments[1] || {});	

		this.refresh();
	},
	refresh: function() {
		var list = this;
		var even = 0;
				
		$$("#" + this.listName + " " + list.options.tag).each(function(element) {		
			/* reset all the behaviours */
			Element.removeClassName(element, 'hover');
			
			if (list.options.show) {
				$A(document.getElementsByClassName(list.options.show, element)).each(function(elementToHide) {
					if (!hasClassName(element, list.options.disableFor))
						Element.hide(elementToHide);
				});
			}
			
			if (list.options.alternateClasses) {
				Element.removeClassName(element, list.options.alternateClasses[0]);
				Element.removeClassName(element, list.options.alternateClasses[1]);
				
				if (!hasClassName(element, list.options.except))
					Element.addClassName(element, !even ? list.options.alternateClasses[0] : list.options.alternateClasses[1]);
				even = even ? 0 : 1;
			}

			if (!list.options.disableFor || !hasClassName(element, list.options.disableFor)) {
				Event.observe(element, 'mouseover', function(e) { 		
					// if (dragging)
					// 	return ;
							
					if (list.options.show) {
						$A(document.getElementsByClassName(list.options.show, element)).each(function(elementToShow) {
							Element.show(elementToShow);
						});
					}
					Element.addClassName(element, 'hover');
	 			}, false);

				Event.observe(element, 'mouseout', function(e) { 
					if (list.options.show) {
						$A(document.getElementsByClassName(list.options.show, element)).each(function(elementToHide) {
							Element.hide(elementToHide);
						});
					}			
					Element.removeClassName(element, 'hover');
	 			}, false);
			}
		});
	},
	forceMouseout: function(element) {
		Element.removeClassName(element, 'hover');
		if (this.options.outFunction)
			this.options.outFunction(element);
	}
}

// =======================================================================


function hasClassName(element, classes) {
	if (classes == null)
		return false;
	if (typeof classes == 'string') {
		// actually, only one class to test 
		return Element.hasClassName(element, classes);
	} else {
		for (var i = 0; i < classes.length; i++) {
			if (Element.hasClassName(element, classes[i]))
				return true;
		}
	}
	return false;
}

// =======================================================================

function hideAllSelectTags(containerName) {
	// hide all the select tags if the browser is IE
	if (/MSIE/.test(navigator.userAgent) == true) {
		$$("#" + containerName + " select").each(function(select) {
			Element.hide(select);
		});
	}
}

function showAllSelectTags(containerName) {
	// hide all the select tags if the browser is IE
	if (/MSIE/.test(navigator.userAgent) == true) {
		$$("#" + containerName + " select").each(function(select) {
			Element.show(select);
		});
	}
}





/*  FROM PF&A, for the Interview feature */

function show_box(section) {
	tabs_to_unselect = $('box_tabs').childNodes;
	divs_to_hide = $('tabbed_box').childNodes;
	
	for(i=0; i<tabs_to_unselect.length; i++) {
		if (tabs_to_unselect[i].nodeType == 1) { //an "Element" node
//			tabs_to_unselect[i].setAttribute('class', 'unselected');
			tabs_to_unselect[i].className = 'unselected';
                }
        }
	
	
	for(i=0; i<divs_to_hide.length; i++) {
		if (divs_to_hide[i].nodeType == 1) { //an "Element" node
			divs_to_hide[i].style.display = 'none';
		}
	}

	preselected_tab = $('current_tab');
	if (preselected_tab != null) {
		preselected_tab.value = section;
	}
	tab = $('tab_'+section);
	if (tab != null) {
//		tab.setAttribute('class','selected');
		tab.className = 'selected';
	}

	condiment = $('content_'+section);
	if (condiment != null) {
		condiment.style.display='block';
	}

}

function recursive_checkbox_click(node) {
	boxes = node.parentNode.parentNode.getElementsByTagName('input');
	for(var i=0; i<boxes.length; i++) 
		boxes[i].checked = node.checked;
}

function aggregate_table_output(node) {
  boxes = node.parentNode.parentNode.getElementsByTagName('input');
  output = boxes[1].value + "~";
  for(var i = 2; i < boxes.length; i++)
  {
    output += boxes[i].value;
    if((i-1)%3 == 0) {
      output += "~";
    } else {
      output += ";";
    }
  }
  boxes[0].value = output;
}

function remove_table_row(node) {
  aggregator=node.parentNode.parentNode.getElementsByTagName('input')[1];
  node.parentNode.parentNode.removeChild(node.parentNode)
  aggregate_table_output(aggregator);
}

function aggregate_chart_output(node) {
  boxes = node.parentNode.parentNode.getElementsByTagName('input');
  output = boxes[1].value + "~";
  for(var i = 2; i < boxes.length; i++)
  {
    output += boxes[i].value;
    if((i-1)%2 == 0) {
      output += "~";
    } else {
      output += ";";
    }
  }
  boxes[0].value = output;
}

function remove_chart_row(node) {
  aggregator=node.parentNode.parentNode.getElementsByTagName('input')[1];
  node.parentNode.parentNode.removeChild(node.parentNode)
  aggregate_chart_output(aggregator);
}

function select_tab(tab_name) {
  tabs_to_hide = $(tab_name).parentNode.childNodes;
  
  unselect_array(tabs_to_hide);
  
  select_element($(tab_name))
}

function show_employee(employee_num) {
  images_to_hide = $('employee_pics').childNodes;
  details_to_hide = $('employee_details').childNodes;
  links_to_unselect = $('employee_links').childNodes;
  
  hide_array(images_to_hide);
  hide_array(details_to_hide);
  unselect_array(links_to_unselect);
  
  show_element('employee_' + employee_num + '_pic');
  show_element('employee_' + employee_num + '_details');
  select_element('employee_' + employee_num + '_link');
  $('employee_'+employee_num+'_name').addClassName('show');
  $('employee_'+employee_num+'_tagline').addClassName('show');
}

function get_next_image() {
  src_list=$('project-thumbnails').getElementsByTagName("span");
  // NOTE: if at end of list, loop back to beginning of image list
  for(i=0; i<src_list.length; i++) {
    if(src_list[i].className=='active') {
      //Adjust new index so images loop
      new_index = (i + 1)%src_list.length;
      src_list[i].className="";
      src_list[new_index].className="active"
      $('image-holder').innerHTML = src_list[new_index].innerHTML
      break;
    }
  }
}

function get_prev_image() {
  src_list=$('project-thumbnails').getElementsByTagName("span");
  // NOTE: if at beginning of list, loop to end of image list
  for(i=0; i<src_list.length; i++) {
    if(src_list[i].className=='active') {
      //Adjust new index so images loop
      new_index = (i + src_list.length - 1)%src_list.length;
      src_list[i].className="";
      src_list[new_index].className="active"
      $('image-holder').innerHTML = src_list[new_index].innerHTML
      break;
    }
  }
}

// Helper functions

function hide_array(arr) {
  for(i=0; i<arr.length; i++) {
		if (arr[i].nodeType == 1) { //an "Element" node
			arr[i].style.display = 'none';
		}
	}
}

function unselect_array(arr) {
  for(i=0; i<arr.length; i++) {
		if (arr[i].nodeType == 1) { //an "Element" node
			arr[i].className = 'unselected';
    }
  }
}

function show_element(elem_name) {
  elem = $(elem_name)
  if(elem != null) {
    elem.style.display = 'block';
  }
}

function select_element(elem_name) {
  elem = $(elem_name)
  if(elem != null) {
    elem.className = 'selected';
  }
}

function set_active(elem_list, elem_name) {
  for(i=0; i<elem_list.length; i++) {
		if (elem_list[i].nodeType == 1) { //an "Element" node
			elem_list[i].className = '';
		}
	}
	
	elem = $(elem_name)
  if(elem != null) {
    elem.className = 'active';
  }
}

function aggregate_table(jsname) {
  table = $('table_' + jsname);
  trs = table.getElementsByTagName('tr');
  rows = [];
  for (i=1;i<trs.length;i++) {
    inputs = trs[i].getElementsByTagName('input');
    something_on_this_row = false;
    row = [];
    for (j=0;j<inputs.length;j++) {
      val = inputs[j].value;
      row.push(val);
      if (val != '') {
        something_on_this_row = true;
      }
    }
    if (something_on_this_row) {
      rows.push(row);
    }
  }
  $(jsname).value = JSON.stringify(rows).replace(/,([\\["])/g,', $1');
  return true;
}
function add_row_to_table(jsname) {
  body_of_table = $('body_of_table_' + jsname);
  //clone the invisible row of empty inputs
  new_row = body_of_table.getElementsByTagName('tr')[0].cloneNode(true);
  new_row.style.display='table-row';
  body_of_table.appendChild(new_row);
}
function remove_row_from_table(jsname, link) {
  link.parentNode.parentNode.parentNode.removeChild(link.parentNode.parentNode);
  aggregate_table(jsname);
}


function import_image(container_id, photo_id) {
	$('import_image_'+container_id).value = photo_id
	$('import_image_'+container_id).parentNode.getElementsByTagName('span')[0].innerHTML = 'Now Save'
	old_image = $('import_image_'+container_id).parentNode.getElementsByTagName('img')[0]
	if (old_image != null && old_image.className == 'interview_image') {
		old_image.style.display = 'none'
	}
	$('more_photos_container_'+container_id).style.display='none'
}

function renderSIFR(theme) {
	if(typeof sIFR == "function"){
		sIFR.replaceElement(named({sSelector:".sifr_light_title",  sFlashSrc:"/flash/sifr.gothamblack-std.black.swf",  sColor:theme['light_title'],  sBgColor:'#FFFFFF',  sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_dark_title", sFlashSrc:"/flash/sifr.gothamblack-std.black.swf", sColor:theme['dark_title'], sBgColor:theme['light_title'], sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_gray_title", sFlashSrc:"/flash/sifr.gothamblack-std.black.swf", sColor:'#4A4A43', sBgColor:'#FFFFFF', sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_white_title", sFlashSrc:"/flash/sifr.gothamblack-std.black.swf", sColor:'#FFFFFF', sBgColor:theme['light_title'], sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_subtitle", sFlashSrc:"/flash/sifr.gotham.light.swf", sColor:'#FFFFFF', sBgColor:theme['light_title'], sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_gray_subtitle", sFlashSrc:"/flash/sifr.gotham.light.swf", sColor:'#4A4A43', sBgColor:'#FFFFFF', sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_gotham_medium", sFlashSrc:"/flash/sifr.gotham.medium.swf", sColor:'#4A4A43', sBgColor:'#FFFFFF', sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_gotham_light_white", sFlashSrc:"/flash/sifr.gotham.light.swf", sColor:'#FFFFFF', sBgColor:theme['light_title'], sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_gotham_medium_white", sFlashSrc:"/flash/sifr.gotham.medium.swf", sColor:'#FFFFFF', sBgColor:theme['light_title'], sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_lubalin_bold", sFlashSrc:"/flash/sifr.lubalin.bold.swf", sColor:'#4A4A43', sBgColor:'#FFFFFF', sWmode:"transparent"}));
		sIFR.replaceElement(named({sSelector:".sifr_lubalin_normal", sFlashSrc:"/flash/sifr.lubalin.normal.swf", sColor:'#4A4A43', sBgColor:'#FFFFFF', sWmode:"transparent"}));
	}
}