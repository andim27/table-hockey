<?php
    // Connecting, selecting database
    $link = mysql_connect("mysql.YOUR_DOMAIN.COM", "USER_DATABASE", "PASSWORD_DATABASE")
       or die("Could not connect");
       
    // print "Connected successfully<p>";
    mysql_select_db("YOUR_DATABASE") or die("Could not select database");
          
     $type  = $_GET["type"];
     $name  = $_GET["name"];
     $level  = $_GET["level"];
     $score  = $_GET["score"];

     //  ++ INSERT DATE ++

     if (checkValid($type))
     {
	insertHighscore( $name, $level, $score );
     }
     else
     {
	 print "OK";
     }
     

     // Closing connection
     mysql_close($link);     
     
     
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     
     // FUNCTIONS
     //**************************************************************************************
     //**************************************************************************************
     //**************************************************************************************     


     //-------------------------------------------------------------
    //  Function checkValid
    //   Check the checksum code received from the user is valid
    //-------------------------------------------------------------
    function checkValid($code_par)
    {
	$output=false;

	// GET CHECKSUM
	$checkSumGame=(int)substr($code_par, 1, 2);

	// GET GAME TIMESTAMP
	$cadTimeStampGame=substr($code_par, 3, -1);
	$timeStampGame=(int)$cadTimeStampGame;
	
	// GET CURRENT TIMESTAMP
	$timeStampNow=time();

	// ++ CHECK DIFERENCE BETWEEN TIMESTAMP (BELOW 30 seconds) ++
	$timeRes=$timeStampNow-$timeStampGame;
	$checkSumResult=-1;
	if (($timeRes>=0)&&($timeRes<30))
	{
		$checkSumResult=0;
		for ($i=0;$i<strlen($cadTimeStampGame);$i++)
		{
		    $digit=(int)substr($cadTimeStampGame, $i, 1);	
		    if (fmod($i,2)==0.0)
		    {
			$checkSumResult=$checkSumResult+$i;
		    }
		    else
		    {
			$checkSumResult=$checkSumResult+$digit;
		    }		    
		    // print "checkSumResult($i)=$checkSumResult\n";
		}
		$checkSumResult=(int)fmod($checkSumResult,100);
		
		// ++ CHECK THE CHECKSUM ++
		if ($checkSumGame==$checkSumResult)
		{
			$output=true;
		}		
	}

	// print "CODE=$code_par\n";
	// print "timeStampNow($timeStampNow)-timeStampGame($timeStampGame)=$timeRes\n";
	// print "CHECKSUM SERVER=$checkSumResult\n";
	// print "CHECKSUM GAME=$checkSumGame\n";

	return ($output);
    }
     
     
     //-------------------------------------------------------------
    //  Function existPlayer
    //   Ask if exist the player
    //-------------------------------------------------------------
    function existPlayer($name_par)
    {
	     // Performing SQL Consult
	     $query_consult = "SELECT count(1) as contar FROM highscore_phyballs WHERE name = '$name_par'";
	     $result_consult = mysql_query($query_consult) or die("(0)Query failed");
	     $row_consult=mysql_fetch_object($result_consult);
	     $numero_entradas=$row_consult->contar;
	
	     // Free resultset
	     mysql_free_result($result_consult);
	
	      if ($numero_entradas==0)
		    return (false);
		 else
		    return (true);
    }

     //-------------------------------------------------------------
     //  Function insertHighscore
     //    Will insert the new score in the table
     //-------------------------------------------------------------
     function insertHighscore( $name_par, $level_par, $score_par )
     {
       // Look if the username is repeated in the table to update the record
       if (existPlayer($name_par, $level_par)>0)
       {
	     // ++ GET SCORE ++
	     $query_consult = "SELECT score FROM highscore_phyballs WHERE name = '$name_par'";
	     $result_consult = mysql_query($query_consult) or die("(1)Query failed");
	     $row_consult=mysql_fetch_object($result_consult);
	     $current_score=$row_consult->score;
	     mysql_free_result($result_consult);

	     // ++ TEST TO UPDATE ++
		if ($current_score < $score_par)
		{
			$query_updatesun = "UPDATE highscore_phyballs SET score = $score_par, level = $level_par WHERE name = '$name_par'";
			$result_updatesun = mysql_query($query_updatesun) or die("(2)Query failed");

			if (mysql_affected_rows()!=1)
			{
			   print "ERROR";
			}
			else
			{
			   print "OK";
			}
		}
       }
       else
       { 

		// ++ GET SCORE ++
		$query_consult = "SELECT max(id) as maximumId FROM highscore_phyballs";
		$result_consult = mysql_query($query_consult) or die("(3)Query failed");
		$row_consult=mysql_fetch_object($result_consult);
		$maxIdentifier=$row_consult->maximumId;
		mysql_free_result($result_consult);
       
		//  ++Insert ++
		$query = "INSERT INTO highscore_phyballs VALUES ($maxIdentifier+1, $level_par, '$name_par', $score_par)";
		$result = mysql_query($query) or die("(4)Query failed ".$name_par. ";" . $score_par );
		
		if (mysql_affected_rows()==1)
			print "OK";
		else
			print "ERROR";
       }
    }

?>
