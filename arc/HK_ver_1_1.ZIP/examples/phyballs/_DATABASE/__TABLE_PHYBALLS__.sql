-- phpMyAdmin SQL Dump
-- version 2.11.9.1
-- http://www.phpmyadmin.net
--
-- Host: mysql.YOUR_DOMAIN.COM
-- Generation Time: Oct 27, 2008 at 03:40 AM
-- Server version: 5.0.67
-- PHP Version: 4.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `YOUR_DATABASE`
--

-- --------------------------------------------------------

--
-- Table structure for table `highscore_phyballs`
--

CREATE TABLE IF NOT EXISTS `highscore_phyballs` (
  `id` bigint(20) NOT NULL,
  `level` smallint(6) default NULL,
  `name` varchar(20) default NULL,
  `score` int(11) default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `highscore_phyballs`
--

INSERT INTO `highscore_phyballs` (`id`, `level`, `name`, `score`) VALUES
(0, 3, 'manolo', 400),
(1, 1, 'wtf', 45),
(2, 2, 'moving on', 305),
(3, 2, 'jander', 30),
(4, 5, 'game over', 465),
(5, 3, 'name player', 930),
(6, 2, 'jarll', 495);
