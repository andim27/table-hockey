<?php
    // Connecting, selecting database
    $link = mysql_connect("mysql.YOUR_DOMAIN.COM", "USER_DATABASE", "PASSWORD_DATABASE")
       or die("Could not connect");

    // print "Connected successfully<p>";
    mysql_select_db("YOUR_DATABASE") or die("Could not select database");

    // ++ GLOBAL HIGHSCORE ++
    $query_consult = "select * from highscore_phyballs ORDER BY score DESC LIMIT 0,100";
    $result_consult = mysql_query($query_consult) or die("Query failed");


        $contador=1;   
        print "<H1>";
        print "<center>PHYBALLS HIGH SCORE</center>";
	print "<table width=600 border=1>";
	   print "<tr bgcolor=#aaaaaa>";
	    print "<td align=center>";
	      print "Ranking";
	    print "</td>";
	    print "<td align=center>";
	      print "Name";
	    print "</td>";
	    print "<td align=center>";
	      print "Score";
	    print "</td>";
	   print "</tr>";


        // Records Listed	
        while (($line = mysql_fetch_object($result_consult))&&($contador<100))
  	{              
	 	print "<tr>";
		 print "<td align=center bgcolor=#".(99-($contador*5))."ffff>";
		 print $contador;
		
		 // name
		 print "</td>";
		 print "<td align=center>";
		 print $line->name;
		 print "</td>";

		 // time 
		 print "</td>";
		 print "<td align=center>";
		 print $line->score;
		 print "</td>";

		 print "</tr>";
        	 $contador=$contador+1;
        }
	print "</table>";
        print "</H1>";

        // Free resultset
        mysql_free_result($result_consult);
 
     // Closing connection
     mysql_close($link);     
 
?>