TUTORIAL FILES
--------------

  Description of the files: 

      _DOCS\FLA_LIBRARY_STRUCTURE.pdf: 

	It contains the description of how is organized the library of the FLA.


      _DOCS\FlowDiagram.swf: 
	
	Contains a simple flow diagram that will show you how is basically the flow of the
game and how is the class structure.

     _DATABASE\
	Contains the PHP files to list and insert records in a table. It's the exported table in SQL format
ready to import in a database.

     _LEVEL_EDITOR\README.txt:

	It contains the instructions of the level editor used to create the levels


      

TUTORIAL
--------

	http://www.freecreationgames.net/?q=node/77

	It's the tutorial which is focused mainly in library Box2DFlash, all other
stuff related with Flash or Game Programming you can find it in these useful tutorial:

	http://freelanceflashgames.com/news/2008/10/07/top-15-flash-tutorial-sites/

