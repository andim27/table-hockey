/**
@file Point.java

Point definition (x,y)
*/
import java.lang.Math;


// ****************************************************
// ****************************************************
/**
 @brief 2D Point definition (x,y)
 
 @author Esteban Gallardo
*/
class Point2D 
{
  
	public int x;                 /**< @brief x coordinate  */
	public int y;                 /**< @brief y coordinate  */

	// Direction Type Constants		
	public static final int NONE 				 = 0;
	public static final int DOWN 				 = 1;
	public static final int UP 					 = 2;
	public static final int RIGHT 				 = 3;
	public static final int LEFT 				 = 4;
	
	// ---------------------------------------------------	
	/**
	 @brief Constructor of Point 
	 */	
	Point2D() 
	{
		this.x=-1;
		this.y=-1;
	}


	// ---------------------------------------------------	
	/**
	 @brief Constructor of Point 
	 
	 @param x coordinate x 
	 @param y coordinate y
	 */	
	Point2D( int x, int y ) 
	{
		this.x=x;
		this.y=y;
	}

	
	// ---------------------------------------------------	
	/**
	 @brief Constructor of Point 
	 
	 @param p object point to copy
	 */	
	Point2D( Point2D p ) 
	{
		this.x=p.x;
		this.y=p.y;
	}

	// ---------------------------------------------------	
	/**
	 @brief Creates a new object of the same class and with the same contents as this object.

	 @param PX coordinate x 
	 @param PY coordinate y
	 
	 @return absolute distance between the two points
	 */	
	 int distance( int PX, int PY ) 
	 {
		 return ((int)(Math.abs(x-PX)+Math.abs(y-PY)));
	 }

	// ---------------------------------------------------	
	/**
	 @brief Determines whether or not two points are equal. 

	 @param obj object to compare to
	 
	 @return true if equal
	*/
	boolean equals( Point2D obj ) 
	{
	  return ((x==obj.x)&&(y==obj.y));
	}

	// ---------------------------------------------------	
	/**
	 @brief Sets the location of this Point2D to the specified coordinates. 

	 @param PX coordinate x 
	 @param PY coordinate y		 
    */
	void setLocation( int x, int y ) 
	{
      this.x=x;
	  this.y=y;
	}

	// ---------------------------------------------------	
	/**
	 @brief Sets the location of this Point2D to the same coordinates as the specified Point2D object. 

	 @param p object point to copy
	*/
	void setLocation( Point2D p ) 
	{
	  this.x=p.x;
	  this.y=p.y;
	}

	// ---------------------------------------------------	
	/**
	 @brief Convert to string representation

	 @return Gives the string representation of Point2D
	 */
	public String toString()
	{
	  return (x+","+y);
	}

	// ---------------------------------------------------
	/**
	 @brief Get the direction to go from init point to end point

	 @param pos_ini init position
	 @param pos_end end position

	 @return the direction to go from pos init to pos end
	 */
	static int getDirection(Point2D a, Point2D b)
	{ 
		 if (b.equals(a)) return (NONE);
		 if ((b.x==a.x)&&(b.y<a.y)) return (DOWN);
		 if ((b.x==a.x)&&(b.y>a.y)) return (UP);
		 if ((b.x>a.x)&&(b.y==a.y)) return (RIGHT);
		 if ((b.x<a.x)&&(b.y==a.y)) return (LEFT);
         
		 return (NONE);
	}

	
	
	// ---------------------------------------------------
	/**
	 @brief Return the point moved in the selected direction with the parameter factor

	 Return the point moved in the selected direction with the parameter factor
	 
	 @param direction the direction to move the point
	 @param factor the number of units to move the point
	 */	
	void moveDirection(int direction, int factor)
	{ 
	    switch (direction) 
	    {
		    case UP:      
			    y+=factor;
                            break;
		    case LEFT: 
			    x-=factor;
                            break;
		    case DOWN:       
			    y-=factor;
                            break;
		    case RIGHT:    
			    x+=factor;
                            break;
	     }
      }
      
	// ---------------------------------------------------
	/**
	 @brief Return the distance between two points

	 Return the distance between two points
	 
	 @param a origin point
	 @param b destination point
      
	 @return returns the distance between two points
	 */
	static int distanceAbsolute(Point2D a, Point2D b)
	{  
	    return(Math.abs(a.x-b.x)+Math.abs(a.y-b.y)); 
	}

    
	// ---------------------------------------------------
	/**
	 @brief Return the direction between two points

	 Return the direction between two points
	 
	 @param a origin point
	 @param b destination point
      
	 @return returns the direction between two points
	 */
	static int getDirectionFrom(Point2D a, Point2D b)
	{ 
		if (a.y>b.y) { return (DOWN);  }
		if (a.y<b.y) { return (UP);	   }

		if (a.x>b.x) { return (LEFT);  }		
		if (a.x<b.x) { return (RIGHT); }
     
		return (NONE);
	}
  
	
}  // End class Point2D
