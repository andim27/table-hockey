/**
@file TileMapEditor.java

Editor of Golf Adventure
*/
import javax.swing.*;
import javax.swing.event.*; 
import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;

//****************************************************
//****************************************************
/**
@brief Main Class that contains the visual components of the editor  

@author Esteban Gallardo
*/
public class TileMapEditor extends JInternalFrame
{
	public static int _NumberOfTiles = 0;
	static final String _tilesRoot="tiles/";/**<@brief Path where the tiles are */
	
	public static byte _NumberLayersCreated = 1;
	
    static JFrame _Frame; 				 /**< @brief Frame of the current dialog */
    static String _Filename=null;		 /**< @brief Filename of the file to load/save */
    
    // JPanel contentPane=null;         /**< @brief Reference to main container */
    JTabbedPane tabbedPane;				/**< @brief Reference to tabbed panel */
	
    // +++++++++++++++++++  Editor Members
    JLabel labelInformation;			 	 /**< @brief Label of information */	
    JSpinner _spinWidth = null;			 /**< @brief Control of the witdh of the world */
    JSpinner _spinHeigth = null; 		 	 /**< @brief Control of the heigth of the world */
    static ScrollWorld _ScrollWorld=null; 		 /**< @brief Instance of canvas scrollworld */

    static int gBlockSize_X=-1;				 /**< @brief The Width block size selected for fucking render */
    static int gBlockSize_Y=-1;				 /**< @brief The Height block size selected for fucking render */
   
    JSpinner  _spinZoom	= null;
    static int gZoomApplied=1;			/**< @brief Zoom applied to render */

	public static Image m_type_collision;		

	public static Image m_type_fruit_1;		
	public static Image m_type_fruit_2;		
	public static Image m_type_fruit_3;		
	public static Image m_type_fruit_4;		
	public static Image m_type_fruit_5;		
	public static Image m_type_fruit_6;
	public static Image m_type_fruit_7;		
	public static Image m_type_fruit_8;		

	

    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // 							 COLLISION TAB
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	// ---------------------------------------------------
	/**
	 @brief Panel to edit the collision map
	 
	 The controls that will let to construct the world
	 */
	private JPanel makeEditorPanel()
	{
	   JPanel panelOut=new JPanel(new GridLayout(17,1));
	   
	   labelInformation=new JLabel("State");
	   panelOut.add(labelInformation);

	   // COLISION_TYPE_EMPTY
   	   JButton buttonTypeDelete=new JButton("DELETE");
	   buttonTypeDelete.addActionListener(new ActionListener() 
	   { 
			public void actionPerformed(ActionEvent e) 
 			{
				labelInformation.setText("DELETE");
			    labelInformation.setIcon(null);
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_EMPTY;
 			}
 		});
	   panelOut.add(buttonTypeDelete);

	   //  COLISION_TYPE_STONE (m_type_collision)
	   JButton buttonTypeCollision = new JButton(new ImageIcon(m_type_collision));
	   buttonTypeCollision.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
				labelInformation.setIcon(new ImageIcon(m_type_collision));
				_ScrollWorld._World.colTypeSelected = World.COLISION_TYPE_STONE;
			}
 	   });
	   panelOut.add(buttonTypeCollision);

	    //  COLISION_TYPE_FRUIT_1 (m_type_fruit_1)	   
	   JButton buttonTypeFruit1=new JButton(new ImageIcon(m_type_fruit_1));
	   buttonTypeFruit1.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_1));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_1;
			}
 	   });
	   panelOut.add(buttonTypeFruit1);
	   
	    // COLISION_TYPE_FRUIT_2 (m_type_fruit_2)	   
	   JButton buttonTypeFruit2=new JButton(new ImageIcon(m_type_fruit_2));
	   buttonTypeFruit2.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_2));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_2;
			}
 	   });
	   panelOut.add(buttonTypeFruit2);
	   
	    // COLISION_TYPE_FRUIT_3 (m_type_fruit_3)	   
	   JButton buttonTypeFruit3=new JButton(new ImageIcon(m_type_fruit_3));
	   buttonTypeFruit3.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_3));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_3;
			}
 	   });
	   panelOut.add(buttonTypeFruit3);
	   
	   // COLISION_TYPE_FRUIT_4 (m_type_fruit_4)	   
	   JButton buttonTypeFruit4=new JButton(new ImageIcon(m_type_fruit_4));
	   buttonTypeFruit4.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_4));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_4;
			}
 	   });
	   panelOut.add(buttonTypeFruit4);
	   
	   // COLISION_TYPE_FRUIT_5 (m_type_fruit_5)	   
	   JButton buttonTypeFruit5=new JButton(new ImageIcon(m_type_fruit_5));
	   buttonTypeFruit5.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_5));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_5;
			}
 	   });
	   panelOut.add(buttonTypeFruit5);
	   
	   // COLISION_TYPE_FRUIT_6 (m_type_fruit_6)	   
	   JButton buttonTypeFruit6=new JButton(new ImageIcon(m_type_fruit_6));
	   buttonTypeFruit6.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_6));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_6;
			}
 	   });
	   panelOut.add(buttonTypeFruit6);
	   
	   // COLISION_TYPE_FRUIT_7 (m_type_fruit_7)	   
	   JButton buttonTypeFruit7=new JButton(new ImageIcon(m_type_fruit_7));
	   buttonTypeFruit7.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_7));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_7;
			}
 	   });
	   panelOut.add(buttonTypeFruit7);
	   
	   // COLISION_TYPE_FRUIT_8 (m_type_fruit_8)	   
	   JButton buttonTypeFruit8=new JButton(new ImageIcon(m_type_fruit_8));
	   buttonTypeFruit8.addActionListener(new ActionListener()
	   {
			public void actionPerformed(ActionEvent e)
 			{
			    labelInformation.setText(null);
			    labelInformation.setIcon(new ImageIcon(m_type_fruit_8));
			    _ScrollWorld._World.colTypeSelected=World.COLISION_TYPE_FRUIT_8;
			}
 	   });
	   panelOut.add(buttonTypeFruit8);
	   
	   // ++++++++++++++++++++	   
	   // SpinnerModel widthModel = new SpinnerNumberModel( 10, 1, 1000, 1);
	   SpinnerModel widthModel = new SpinnerNumberModel( _ScrollWorld._World.iMatrixWidth, 1, 1000, 1);
	   _spinWidth = new JSpinner(widthModel);
	   _spinWidth.addChangeListener(new ChangeListener()
	   {
	       public void stateChanged(ChangeEvent e) 
	       {
	           System.out.println(((Integer)_spinWidth.getValue()).intValue());
	           try 
	           {
	            System.out.println(((Integer)_spinHeigth.getValue()).intValue());
	            int tmpWidth=((Integer)_spinWidth.getValue()).intValue();
	            int tmpHeight=((Integer)_spinHeigth.getValue()).intValue();
	            // int tmpZoom=((Integer)_spinZoom.getValue()).intValue();
	            _ScrollWorld._World.init(tmpWidth,tmpHeight,gBlockSize_X,gBlockSize_Y);
	           }catch (Exception ed)
	           	{
	               ed.printStackTrace();   
	           	}
	        }
	   });
	   panelOut.add(_spinWidth);
	   

	   // SpinnerModel heigthModel = new SpinnerNumberModel( 10, 1, 1000, 1);
	   SpinnerModel heigthModel = new SpinnerNumberModel( _ScrollWorld._World.iMatrixHeight, 1, 1000, 1);
	   _spinHeigth = new JSpinner(heigthModel);
	   _spinHeigth.addChangeListener(new ChangeListener()
	    	   {
	    	       public void stateChanged(ChangeEvent e) 
	    	       {
	    	           try 
	    	           {
	    	            System.out.println(((Integer)_spinHeigth.getValue()).intValue());
	    	            int tmpWidth=((Integer)_spinWidth.getValue()).intValue();
	    	            int tmpHeight=((Integer)_spinHeigth.getValue()).intValue();
	    	            // int tmpZoom=((Integer)_spinZoom.getValue()).intValue();
	    	            _ScrollWorld._World.init(tmpWidth,tmpHeight,gBlockSize_X,gBlockSize_Y);
	    	           }catch (Exception ed)
	    	           	{
	    	               ed.printStackTrace();   
	    	           	}
	    	       }
	    	   });
	   panelOut.add(_spinHeigth);	  

	   // SpinnerModel heigthModel = new SpinnerNumberModel( 10, 1, 1000, 1);
	   SpinnerModel zoomModel = new SpinnerNumberModel( 1, 1, 1000, 1);
	   _spinZoom = new JSpinner(zoomModel);
	   _spinZoom.addChangeListener(new ChangeListener()
	    	   {
	    	       public void stateChanged(ChangeEvent e) 
	    	       {
	    	           try 
	    	           {
	    	            System.out.println(((Integer)_spinZoom.getValue()).intValue());
			    gZoomApplied=((Integer)_spinZoom.getValue()).intValue();
			      int tmpWidth=((Integer)_spinWidth.getValue()).intValue();
			    int tmpHeight=((Integer)_spinHeigth.getValue()).intValue();
				   _ScrollWorld._World.setZoom(tmpWidth,tmpHeight,gBlockSize_X,gBlockSize_Y,gZoomApplied);
	    	           }catch (Exception ed)
	    	           	{
	    	               ed.printStackTrace();   
	    	           	}
	    	       }
	    	   });
	   panelOut.add(_spinZoom);		

	   return (panelOut);
	}

	








	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MAIN CALL
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	// ---------------------------------------------------
	/**
	 @brief Construction of all the internal frame
	 */
	private void initializeEditorComponent() 
	{		
	   try 
	   {
		JPanel contentPane = (JPanel)this.getContentPane(); 
		contentPane.setLayout(new BorderLayout());		
		   
		if (_Filename==null)
		    _ScrollWorld=new ScrollWorld();
		else
		    _ScrollWorld=new ScrollWorld(_Filename);
		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("COLISION", makeEditorPanel()); 
		tabbedPane.addChangeListener(new ChangeListener() 
		{
			 public void stateChanged(ChangeEvent e) 
			 {
				 System.out.println("TABULADOR CAMBIADO A="+tabbedPane.getSelectedIndex());
				 _ScrollWorld.editionMode=tabbedPane.getSelectedIndex();
			 }
		});
		contentPane.add(_ScrollWorld,BorderLayout.CENTER);
		contentPane.add(tabbedPane,BorderLayout.EAST);
		this.setTitle("LevelEditor");
		this.setLocation(new Point(0, 0));
		this.setSize(new Dimension(600, 600));
		this.setClosable(true); 
 		this.setIconifiable(true); 
 		this.setMaximizable(true); 
 		this.setResizable(true);
	   } catch (Exception ed) 
	   {
	       ed.printStackTrace();
	   };
	} 

	
	// ---------------------------------------------------
	/**
	 @brief Main Constructor "New"
	 */
	public TileMapEditor(JFrame frame, int psizeBlock_X, int psizeBlock_Y) 
	{ 
		super(); 
		_Frame=frame;
		gBlockSize_X=psizeBlock_X;
		gBlockSize_Y=psizeBlock_Y;
		initializeEditorComponent(); 
		this.setVisible(true); 
	} 

	// ---------------------------------------------------
	/**
	 @brief Main Constructor "Load"
	 */
	public TileMapEditor(JFrame frame, String filename, int psizeBlock_X, int psizeBlock_Y)
	{ 
		super(); 
		_Frame=frame;
		_Filename=new String(filename);
		gBlockSize_X=psizeBlock_X;
		gBlockSize_Y=psizeBlock_Y;
		initializeEditorComponent();
		this.setVisible(true);
	} 

    // +++++++++++++++++++  Player Members	
	// cMIDlet cmidletGame;
		
	// ---------------------------------------------------
	/**
	 @brief Construction of all the internal frame
	 */
	private void initializePlayerComponent(int screen_width, int screen_height, int cameraType) 
	{
/*	   try 
	   {
		JPanel contentPane = (JPanel)this.getContentPane(); 
		contentPane.setLayout(new BorderLayout());
		cmidletGame=null;
		System.gc();
		cmidletGame=new cMIDlet(_Filename,cameraType);
		contentPane.add(cmidletGame,BorderLayout.CENTER);
		this.setTitle("Window");
		this.setLocation(new Point(0, 0));
		this.setSize(new Dimension(screen_width, screen_height)); 
		this.setClosable(true);
 		this.setIconifiable(true);
 		this.setMaximizable(true);
 		this.setResizable(true);			
			
		addInternalFrameListener(new InternalFrameListener() 
		{
			 public void internalFrameActivated(InternalFrameEvent e){};
			  
			 public void internalFrameClosed(InternalFrameEvent e)
			 {
				System.out.println("--------------------------DESTRUYENDO JUEGO--------------------------");
				try 
				{
				   cmidletGame.destroy();
				}
				catch (Exception eD) {};
			 }
			 public void internalFrameClosing(InternalFrameEvent e){};
			 public void internalFrameDeactivated(InternalFrameEvent e){};
			 public void internalFrameDeiconified(InternalFrameEvent e){};
			 public void internalFrameIconified(InternalFrameEvent e){};
			 public void internalFrameOpened(InternalFrameEvent e){};
		  });
			
	   } catch (Exception ed) 
	   {
	       ed.printStackTrace();
	   };
*/
	} 

	// ---------------------------------------------------
	/**
	 @brief Main Constructor "Load"
	 */
	public TileMapEditor(JFrame frame, String filename, int psizeBlock_X, int psizeBlock_Y, boolean player)
	{ 
		super(); 
		_Frame=frame;
		_Filename=new String(filename);
		gBlockSize_X=psizeBlock_X;
		gBlockSize_Y=psizeBlock_Y;
		initializePlayerComponent(240, 320, 0);
		this.setVisible(true);
	} 
	
  
	// ---------------------------------------------------
	/**
	 @brief Main call that will construct the file menu elements of the frame window
	 
	 @param args Arguments for the program
	 */
	public static void main(String[] args) 
	{ 
		JFrame.setDefaultLookAndFeelDecorated(true); 
		JDialog.setDefaultLookAndFeelDecorated(true); 
		try 
		{ 
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); 
		} 
		catch (Exception ex) 
		{ 
			System.out.println("Failed loading L&F: "); 
			System.out.println(ex); 
		} 
		final JFrame w 	= new JFrame("Level Editor");
		
		final int efectiveTileSize_X=Integer.parseInt(args[0]);
		final int efectiveTileSize_Y=Integer.parseInt(args[1]);
		
		// Set up the "Application" menu		
		final JDesktopPane desktop = new JDesktopPane(); 
		JMenuBar menuBar 	      = new JMenuBar(); 
		JMenu menu 		      = new JMenu("File");
		w.setContentPane(desktop);
		w.setJMenuBar(menuBar);
		w.setSize(new Dimension(10, 10)); 
		menuBar.add(menu);		
		
		// Set up the "File" menu		
		JMenuItem newItem 	= new JMenuItem("New");
		JMenuItem loadItem 	= new JMenuItem("Load");
		JMenuItem saveItem 	= new JMenuItem("Save");
		JMenuItem playItem 	= new JMenuItem("Play");
		JMenuItem saveItemXML= new JMenuItem("Export XML");
		
		menu.add(newItem);
		menu.add(loadItem);
		menu.add(saveItem);
		menu.add(saveItemXML);

	   try 
		{
			m_type_collision = (new ImageIcon(_tilesRoot + "01_type_stone.png")).getImage();

			m_type_fruit_1=(new ImageIcon(_tilesRoot+"04_type_fruit_1.png")).getImage();
			m_type_fruit_2=(new ImageIcon(_tilesRoot+"05_type_fruit_2.png")).getImage();
			m_type_fruit_3=(new ImageIcon(_tilesRoot+"06_type_fruit_3.png")).getImage();	
			m_type_fruit_4=(new ImageIcon(_tilesRoot+"07_type_fruit_4.png")).getImage();
			m_type_fruit_5=(new ImageIcon(_tilesRoot+"08_type_fruit_5.png")).getImage();
			m_type_fruit_6=(new ImageIcon(_tilesRoot+"09_type_fruit_6.png")).getImage();
			m_type_fruit_7=(new ImageIcon(_tilesRoot+"10_type_fruit_7.png")).getImage();
			m_type_fruit_8=(new ImageIcon(_tilesRoot+"11_type_fruit_8.png")).getImage();
		
	   } catch (Exception ed) 
	   {
	       ed.printStackTrace();
	   };		
	   

		// "New" Option
		newItem.addActionListener(new java.awt.event.ActionListener() 
		{ 
			public void actionPerformed(java.awt.event.ActionEvent e) 
			{ 
				// -- Create a New World -- 
				TileMapEditor JIF = new TileMapEditor(w,efectiveTileSize_X,efectiveTileSize_Y);
				desktop.add(JIF);
				try 
				{ 
					JIF.setSelected(true); 
				} 
				catch (java.beans.PropertyVetoException ee) {} 
				//--------------------- 
			}}
		);
		
		// "Load" Option
		loadItem.addActionListener(new java.awt.event.ActionListener() 
		{ 
			public void actionPerformed(java.awt.event.ActionEvent e) 
			{ 
			FileDialog loadWorld=new FileDialog(w, "LOAD WORLD",FileDialog.LOAD);
			loadWorld.show();
	                System.out.println("Opening: " + loadWorld.getDirectory()+loadWorld.getFile() + ".");
			// -- Load a World -- 
	                TileMapEditor JIF = new TileMapEditor(w,loadWorld.getDirectory()+loadWorld.getFile(),efectiveTileSize_X,efectiveTileSize_Y); 
			desktop.add(JIF); 
			try 
			{ 
				JIF.setSelected(true); 
			} 
			catch (java.beans.PropertyVetoException ee) {} 
			}}
		); 

		// "Save" Option
		saveItem.addActionListener(new java.awt.event.ActionListener() 
		{ 
			public void actionPerformed(java.awt.event.ActionEvent e) 
			{
			FileDialog saveWorld=new FileDialog(w, "SAVE WORLD", FileDialog.SAVE);
			saveWorld.show();
	                System.out.println("Saving... " + saveWorld.getDirectory()+saveWorld.getFile()+ ".");
			// -- Save the World --
	                try 
	                {
	                    TileMapEditor._ScrollWorld._World.saveWorld(saveWorld.getDirectory()+saveWorld.getFile());
	                }
	                catch (IOException ed) {}
			}}
		); 

			
		// "Save XML" Option
		saveItemXML.addActionListener(new java.awt.event.ActionListener() 
		{ 
			public void actionPerformed(java.awt.event.ActionEvent e) 
			{
			FileDialog saveWorld=new FileDialog(w, "EXPORT WORLD XML", FileDialog.SAVE);
			saveWorld.show();
	                System.out.println("EXPORT XML... " + saveWorld.getDirectory()+saveWorld.getFile()+ ".");
					// -- Save the World --
	                try 
	                {
	                    TileMapEditor._ScrollWorld._World.saveWorldXML(saveWorld.getDirectory()+saveWorld.getFile());
	                }
	                catch (IOException ed) {}
			}}
		); 

		
			
		w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		w.setSize(700,500);
		w.setLocation(50,50);
		w.setVisible(true);
	} 
} 
  
 