LEVEL EDITOR
------------

It's a simple level editor where you can create the levels. It has been done fast and it's recommended to
close the program after editing one level.


FOLDER STRUCTURE:
-----------------

  _code\ 

	It contains the source code of the editor (JAVA files)


  levels\
	
	It contains the levels in binary format. You have to save all your levels in this
format and load again in this format.

 
  tiles\

	Tiles used for the editor

  
  xml\ 

	Finally, when you have designed a level you must export it to XML.



INSTRUCTIONS
------------

  1. Get sure that you have JRE in your computer:

	http://java.com/en/download/

     If you want to modify the source files then you will need the (Java SE Development Kit (JDK)):

	http://java.sun.com/javase/downloads/index.jsp


  2. Execute file:

	run_editor.bat


  3. Create/Modify a level:

	  File->New

		Create a new level and click on the button of the tiles and paint the area.

	  File->Load

	        Load an existing level

	  File->Save

	        Save the current level

	  File->Export XML

	        The level is exported to XML data that will be used by the FLA. 
		Remember that you CAN NOT LOAD A XML FILE WITH THE EDITOR.